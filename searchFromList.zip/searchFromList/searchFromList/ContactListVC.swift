
import UIKit

class ContactListVC: UIViewController {
    
    //MARK:- Variable Declaration
    
    /* TextField */
    @IBOutlet weak var txtSearch: UITextField!
    
    /* Label */
    @IBOutlet weak var lblNoData: UILabel!
    
    /* TableView */
    @IBOutlet weak var tblView: UITableView!
    
    /* Local Variable */
    var objMainList:[JSON] = [JSON]()
    var objList:[JSON] = [JSON]()
    var strBusinessName = ""
  
    //MARK:- View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        /* Set Data */
        objMainList.append([
            "id":"1",
            "companyName":"ABC",
            "contactName":"johny Smith",
            "image":"b_card3.png"])
        
        objMainList.append([
            "id":"2",
            "companyName":"CIA",
            "contactName":"Phill Collins",
            "image":"b_card3.png"])
        
        objMainList.append([
            "id":"3",
            "companyName":"Lightly",
            "contactName":"Michen Jack",
            "image":"b_card3.png"])
        
        objMainList.append([
            "id":"4",
            "companyName":"Marketing",
            "contactName":"Mark Anthony",
            "image":"b_card3.png"])
        
        objMainList.append([
            "id":"5",
            "companyName":"Park",
            "contactName":"Laura Branighan",
            "image":"b_card3.png"])
        
        objList = objMainList
        
        tblView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

// MARK: - TextField Delegate

extension ContactListVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        /* Check input max lenth */
        let maxLength = (textField.text?.length)! + string.length - range.length;
        return (maxLength > Int(textField.minimumFontSize)) ? false : true;
    }
    
    @IBAction func textFieldValueChanged(_ sender: UITextField) {
        
        if txtSearch.text == nil || txtSearch.text?.length == 0 {
            objList = objMainList
            
        } else {
            
            objList = objMainList.filter {
                return $0["companyName"].stringValue.uppercased().contains(txtSearch.text!.uppercased())
                    || $0["contactName"].stringValue.uppercased().contains(txtSearch.text!.uppercased())
            }
        }
        
        lblNoData.isHidden = objList.count > 0
        
        tblView.reloadData()
    }
    
}

// MARK: - TableView Delegate

extension ContactListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return objList.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ContactListCell! = tableView.dequeueReusableCell(withIdentifier: "ContactListCell") as? ContactListCell
        
        cell.imgCard.image = UIImage(named: objList[indexPath.row]["image"].stringValue)
        
        //  cell.imgCard.sd_setImage(objList[indexPath.row]["image"].stringValue, placeholder: "product_placeholder.png")
        
        cell.lblComapnyName.text = objList[indexPath.row]["companyName"].stringValue
        cell.lblContactName.text = objList[indexPath.row]["contactName"].stringValue
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        
    }
}

