
import UIKit

class ContactListCell: UITableViewCell {
    
    /* ImageView */
    @IBOutlet weak var imgCard: UIImageView!
    
    /* Label */
    @IBOutlet weak var lblComapnyName: UILabel!
    @IBOutlet weak var lblContactName: UILabel!
 
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
